# Web2APK Studio (MVP)

ဒီ project က Android ဖုန်းတစ်လုံးတည်းနဲ့ GitHub မှာတင်ပြီး စမ်းသပ်နိုင်ဖို့ ရည်ရွယ်ထားတဲ့ starter project ဖြစ်ပါတယ်။

## ပါဝင်တာ
- Dark theme UI
- HTML/CSS/JS editor (ရိုးရှင်းတဲ့ textarea editor)
- Preview
- HTML → APK build request
- Website URL → APK build request
- Express backend က GitHub Actions workflow ကို trigger လုပ်ပေးခြင်း
- APK ကို GitHub Actions artifact မှတစ်ဆင့် download လုပ်ခြင်း

## အရေးကြီးတဲ့ ကန့်သတ်ချက်
1. GitHub Actions workflow_dispatch input အရွယ်အစားကန့်သတ်ချက်ကြောင့် HTML source ကို 30 KB အောက်ထားပါ။
2. URL mode က website ကို WebView ထဲမှာ ဖွင့်ပေးတာသာဖြစ်ပြီး website ကို offline အဖြစ် download လုပ်ပေးတာ မဟုတ်ပါ။
3. MVP မှာ App icon/package ID ကို UI ကနေ သတ်မှတ်တာကို နောက်အဆင့်မှာ ထပ်တိုးနိုင်ပါတယ်။ လက်ရှိ Android package id ကို `com.example.web2apk` သတ်မှတ်ထားပါတယ်။
4. APK build ကို အပြည့်အဝ စမ်းသပ်ပြီးသားလို့ မယူဆပါနှင့်။ ပထမ build မှာ GitHub Actions logs ထဲက error ကိုကြည့်ပြီး လိုအပ်ရင် ပြင်ရပါမယ်။
5. Public repository နဲ့ public artifact တွေမှာ source code ပေါ်နိုင်ပါတယ်။ Private code အတွက် repository visibility နဲ့ token permissions ကို ဂရုစိုက်ပါ။

## လိုအပ်တာ
- GitHub account
- Node.js 20+ (backend host မှာ)
- GitHub repository ထဲမှာ ဒီ project ကို upload လုပ်ထားခြင်း
- GitHub token ကို backend hosting service ရဲ့ Environment Variables မှ ထည့်ခြင်း

## A. GitHub repo ပြင်ဆင်ခြင်း (ဖုန်းကနေ)
1. GitHub မှာ repository အသစ်ဖန်တီးပါ။ ဥပမာ `web2apk-studio`။
2. ဒီ ZIP ကို extract လုပ်ပါ။
3. အထဲကဖိုင်တွေကို repository ထဲ upload လုပ်ပါ။ `.github/workflows/build-apk.yml` ပါသွားရပါမယ်။
4. Repo → Settings → Actions → General ကိုဝင်ပြီး Actions ခွင့်ပြုထားကြောင်း စစ်ပါ။
5. GitHub Actions tab ထဲမှာ `Build Web2APK` workflow ပေါ်လာရပါမယ်။

## B. Backend တင်ခြင်း
Backend က Node.js service အဖြစ် run ရပါမယ်။ Static hosting (GitHub Pages) တစ်ခုတည်းနဲ့ backend မရပါဘူး။

Backend hosting ရဲ့ Environment Variables:
- `GITHUB_TOKEN` = ကိုယ်ပိုင် GitHub token (repo Actions workflow dispatch / Actions read / artifacts read လုပ်နိုင်တဲ့ အနည်းဆုံး permission ပေးပါ)
- `GITHUB_OWNER` = GitHub username သို့မဟုတ် organization
- `GITHUB_REPO` = `web2apk-studio`
- `GITHUB_WORKFLOW` = `build-apk.yml`
- `GITHUB_BRANCH` = `main`
- `PORT` = hosting service က သတ်မှတ်ပေးရင် အလိုအလျောက်သုံးမယ်

GitHub token ကို HTML/JavaScript ထဲ လုံးဝမထည့်ပါနဲ့။ Public repo ထဲ မတင်ပါနဲ့။ Backend secret အဖြစ်ပဲ ထည့်ပါ။ Token ကို အခြားသူနဲ့ မမျှဝေပါနဲ့။

Backend deploy လုပ်ပြီး URL ရလာရင် `public/app.js` ထဲက `API_BASE` ကို အဲဒီ URL နဲ့ပြောင်းပါ။ ဥပမာ `https://your-backend.example.com`။ Trailing slash မထည့်ပါနဲ့။

## C. Local test (Computer ရှိရင်)
```bash
cd server
npm install
GITHUB_TOKEN=... GITHUB_OWNER=... GITHUB_REPO=web2apk-studio npm start
```
ဖုန်းတစ်လုံးတည်းဆိုရင် backend hosting ရဲ့ web editor / GitHub integration ကို အသုံးပြုနိုင်ပေမယ့် host တစ်ခုချင်းစီရဲ့ free-tier အခြေအနေက ပြောင်းလဲနိုင်ပါတယ်။

## D. အသုံးပြုပုံ
1. Website ကိုဖွင့်ပါ။
2. `HTML Editor` ထဲမှာ HTML ထည့်ပါ သို့မဟုတ် `Website URL` ကိုရွေးပါ။
3. `Build APK` ကိုနှိပ်ပါ။
4. Build request လက်ခံရင် GitHub Actions က Android APK ကို compile လုပ်ပါမယ်။
5. Website မှာ Build status ကိုစစ်ပြီး APK ရလာရင် Download လုပ်ပါ။

## Troubleshooting
- `Backend URL not configured`: `public/app.js` ရဲ့ `API_BASE` ကိုပြင်ပါ။
- `GitHub configuration missing`: backend environment variables မပြည့်စုံပါ။
- `Workflow not found` / `404`: `GITHUB_OWNER`, `GITHUB_REPO`, `GITHUB_WORKFLOW` ကိုစစ်ပါ။
- `Resource not accessible by integration`: token permission မလုံလောက်ပါ။
- `Build failed`: GitHub → Actions → Build Web2APK → run → logs ကိုဖွင့်ကြည့်ပါ။
- URL က WebView ထဲမှာ မပွင့်ရင် website က login, anti-bot, unsupported redirects သို့မဟုတ် network policy လိုအပ်နေနိုင်ပါတယ်။

## Security
ဒီ MVP ကို public anonymous service အဖြစ် တိုက်ရိုက်မဖွင့်ပါနဲ့။ Rate limit, authentication, HTML size validation, abuse prevention နဲ့ build concurrency controls ထည့်ပြီးမှ public အတွက် အသုံးပြုပါ။
